/**
 * 
 */
/**
 * @author 2126448
 *
 */
module eCartApplicationAssignment {
}